package Hw1_23001908_VuQuangNam.ex3;

public interface Comparable {
}
