package Hw2_23001908_VuQuangNam.Ex5;

public class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
