package Hw2_23001908_VuQuangNam.Ex1;

public interface MyIterator {
    boolean hasNext();
    Fraction next();
}
