package Hw2_23001908_VuQuangNam.Ex1;

public class Node {
    Node next;
    Fraction fraction;

    public Node(Fraction fraction) {
        this.fraction = fraction;
    }
}
